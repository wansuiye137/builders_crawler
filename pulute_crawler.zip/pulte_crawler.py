import requests
from bs4 import BeautifulSoup
import csv
import re
from datetime import datetime
import os
import time
import logging
from playwright.sync_api import sync_playwright
from urllib.parse import urljoin
import traceback

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('pulte_scraper.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)


def extract_communities_from_region(region_url):
    communities = []
    try:
        with sync_playwright() as p:
            # 启动浏览器
            browser = p.chromium.launch(
                headless=True,
                args=[
                    '--disable-gpu',
                    '--disable-dev-shm-usage',
                    '--disable-setuid-sandbox',
                    '--no-sandbox'
                ]
            )

            # 创建上下文
            context = browser.new_context(
                viewport={'width': 1920, 'height': 1080},
                java_script_enabled=True,
                ignore_https_errors=True,
                bypass_csp=True
            )

            def route_handler(route):
                resource_type = route.request.resource_type
                if resource_type in ["image", "stylesheet", "font", "media"]:
                    route.abort()
                else:
                    route.continue_()

            context.route("**/*", route_handler)

            page = context.new_page()

            # 导航
            logging.info(f"开始加载区域页面: {region_url}")
            page.goto(region_url, timeout=120000, wait_until="domcontentloaded")
            logging.info(f"区域页面加载完成: {region_url}")

            # 智能等待定位元素
            try:
                # 等待页面关键元素出现 - 使用更具体的容器选择器
                page.wait_for_selector('div.ProductSummary__communityContainer', timeout=30000)
                logging.info(f"找到社区容器: {region_url}")

                # 查找所有社区卡片容器
                community_containers = page.query_selector_all('div.ProductSummary__communityContainer')
                logging.info(f"找到 {len(community_containers)} 个社区容器")

                if not community_containers:
                    return []

                # 遍历所有社区容器
                for container in community_containers:
                    try:
                        # 查找社区卡片
                        community_cards = container.query_selector_all('div.ProductSummary__community.row')
                        logging.info(f"在容器中找到 {len(community_cards)} 个社区卡片")

                        for card in community_cards:
                            try:
                                # 在卡片内查找按钮区域
                                button_div = card.query_selector('div.ProductSummary__buttons')
                                if not button_div:
                                    button_div = card.query_selector('div.col-sm-12.u-xs-noPad')

                                if not button_div:
                                    continue

                                # 在按钮区域内查找链接元素
                                link_tag = button_div.query_selector('a[data-href]')
                                if not link_tag:
                                    link_tag = button_div.query_selector('a[data-target="#modal-experience"]')
                                if not link_tag:

                                    link_tag = button_div.query_selector('a.experience-modal-button')

                                if not link_tag:
                                    link_tag = button_div.query_selector('text="View Community"')

                                if not link_tag:
                                    continue

                                # 获取链接属性
                                data_href = link_tag.get_attribute('data-href')
                                if not data_href:
                                    # 尝试获取href属性作为备选
                                    data_href = link_tag.get_attribute('href')

                                if not data_href:
                                    continue

                                # 构建完整URL
                                if data_href.startswith("/"):
                                    community_url = f"https://www.pulte.com{data_href}"
                                elif data_href.startswith("http"):
                                    community_url = data_href
                                else:
                                    community_url = urljoin("https://www.pulte.com/", data_href)

                                # 获取社区名称
                                name_element = card.query_selector('h2.ProductSummary__name')
                                if not name_element:
                                    name_element = card.query_selector('h2.heading-secondary')

                                community_name = name_element.text_content().strip() if name_element else "未知社区"

                                communities.append({
                                    "name": community_name,
                                    "url": community_url
                                })

                            except Exception as e:
                                logging.warning(f"处理卡片时出错: {str(e)}")
                                continue

                    except Exception as e:
                        logging.warning(f"处理容器时出错: {str(e)}")
                        continue

                return communities

            except Exception as e:
                logging.error(f"元素定位失败: {str(e)}")
                return []

            finally:
                browser.close()
                logging.info(f"浏览器关闭: {region_url}")

    except Exception as e:
        logging.error(f"处理区域页面时出错: {str(e)}")
        logging.error(traceback.format_exc())
        return []


def extract_home_links(community_url):
    """
    从社区页面提取所有房源的URL
    """
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    }

    home_links = []
    community_name = ""

    try:
        response = requests.get(community_url, headers=headers, timeout=30)
        response.raise_for_status()
        soup = BeautifulSoup(response.content, 'html.parser')

        # 提取社区名称用于日志
        community_name = community_url.split('/')[-1] if community_url.split('/')[-1] else "community"

        # 1. 提取Quick Move-In房源的URL
        quick_move_section = soup.find('div', class_='HomeDesignSummary__section-container')
        if quick_move_section:
            qmi_cards = quick_move_section.find_all('a', class_='QMIGridCard__cta')
            for card in qmi_cards:
                href = card.get('href')
                if href and href.startswith('/homes/'):
                    full_url = f"https://www.pulte.com{href}"
                    home_links.append(full_url)

        # 2. 提取Home Design房源的URL
        home_design_section = soup.find('div', id='exactMatches')
        if not home_design_section:
            home_design_section = soup.find('div', class_='HomeDesignSummary__card-container')

        if home_design_section:
            design_cards = home_design_section.find_all('a', class_='GridCard__cta')
            for card in design_cards:
                href = card.get('href')
                if href and href.startswith('/homes/'):
                    full_url = f"https://www.pulte.com{href}"
                    home_links.append(full_url)

        logging.info(f"在社区页面 {community_url} 中找到 {len(home_links)} 个房源")
        return home_links, community_name

    except Exception as e:
        logging.error(f"提取房源链接时出错: {str(e)}")
        logging.error(traceback.format_exc())
        return [], community_name


def scrape_home_detail(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    }

    # 从URL提取基本信息
    parts = url.split('/')
    state = parts[4] if len(parts) > 4 else ''
    city = parts[6] if len(parts) > 6 else ''
    community = parts[7] if len(parts) > 7 else ''
    community = re.sub(r'-\d+$', '', community)
    home_id = parts[-1] if parts else ''

    try:
        response = requests.get(url, headers=headers, timeout=30)
        response.raise_for_status()
        soup = BeautifulSoup(response.content, 'html.parser')

        # 提取计划类型
        plan_div = soup.find('div', class_='QmiHero__series')
        plan_type = plan_div.get_text(strip=True).replace('Series:', '').strip() if plan_div else ''

        # 初始化地址信息变量
        address = ''
        zip_code = ''

        # 检查是否为HomeDesign页面
        plan_overview = soup.find('div', class_='PlanOverview__information')
        if plan_overview:
            # ====== HomeDesign页面处理逻辑 ======
            # 状态设为HomeDesign
            status = "HomeDesign"

            # 提取地址信息（新位置）
            address_div = soup.find('div', class_='CommunityPersistentNav__address')
            if address_div:
                full_address = address_div.get_text(strip=True)
                # 分割地址信息
                address_parts = [part.strip() for part in full_address.split(',')]

                # 提取地址（第一个部分）
                if len(address_parts) > 0:
                    address = address_parts[0]

                # 提取城市和州（中间部分）
                if len(address_parts) > 1:
                    # 城市是倒数第二部分
                    city = address_parts[-2].strip()

                # 提取邮编（最后5位数字）
                zip_match = re.search(r'\b(\d{5})\b', full_address)
                if zip_match:
                    zip_code = zip_match.group(1)

            # 提取价格
            price = ""
            price_div = soup.find('div', class_='PlanOverview__home-price')
            if price_div:
                price_span = price_div.find('span', class_='price-amount')
                if price_span:
                    price = price_span.get_text(strip=True)
                    # 清理价格数据（移除非数字字符）
                    price = re.sub(r'[^\d.]', '', price)  # 保留数字和小数点

            # 初始化房屋特征
            stats = {
                'bedrooms': '',
                'bathrooms': '',
                'garage': '',
                'sqft': '',
                'floors': ''
            }

            # 提取房屋特征
            bottom_stats = soup.find('div', class_='PlanOverview__bottom-stats')
            if bottom_stats:
                stats_items = bottom_stats.find_all('div', class_='PlanOverview__stats-item')
                for item in stats_items:
                    label = item.find('span', class_='label')
                    value = item.find('h4')
                    if label and value:
                        label_text = label.get_text(strip=True)
                        value_text = value.get_text(strip=True)
                        if 'Bedrooms' in label_text:
                            stats['bedrooms'] = value_text
                        elif 'Bathrooms' in label_text:
                            stats['bathrooms'] = value_text
                        elif 'Garage' in label_text:
                            # 提取数字部分
                            garage_value = re.findall(r'\d+', value_text)
                            stats['garage'] = garage_value[0] if garage_value else value_text
                        elif 'Sq Ft' in label_text or 'Square Feet' in label_text:
                            stats['sqft'] = value_text
                        elif 'Stories' in label_text:
                            stats['floors'] = value_text

            # 组装HomeDesign数据
            home_data = {
                'date_scraped': datetime.now().strftime('%Y-%m-%d'),
                'builder': 'Pulte',
                'brand': 'pulte',
                'community': community,
                'address': address,
                'city': city,
                'state': state,
                'zip': zip_code,
                'plan_type': plan_type,
                'plan': plan_type,  # 与plan_type相同
                'floors': stats['floors'],
                'bedrooms': stats['bedrooms'],
                'full_bathrooms': stats['bathrooms'],  # 网站未区分全半卫
                'half_bathrooms': '',  # 网站未提供半卫信息
                'garage': stats['garage'],
                'sqft': stats['sqft'],
                'price': price,
                'home_id': home_id,
                'status': status,
                'link': url
            }

            return home_data

        else:
            # ====== 现房页面处理逻辑 ======
            # 提取地址信息（原位置）
            address_span = soup.find('span', itemprop='streetAddress')
            address = address_span.get_text(strip=True).replace(',', '').strip() if address_span else ''

            city_span = soup.find('span', itemprop='addressLocality')
            city = city_span.get_text(strip=True) if city_span else city

            state_span = soup.find('span', itemprop='addressRegion')
            state = state_span.get_text(strip=True) if state_span else state

            zip_span = soup.find('span', itemprop='postalCode')
            zip_code = zip_span.get_text(strip=True) if zip_span else ''

            container = soup.find('div', class_=lambda c: c and 'QmiHero__statsHead' in c)
            price = None
            status = None

            if container:
                # 提取所有Qmi-stat块
                stats = container.find_all('div', class_='Qmi-stat')

                # 1. 提取PRICE：优先红色价格 -> 其次"Now"标签 -> 最后首个有效价格
                for stat in stats:
                    stat_data = stat.find('div', class_='stat-data')
                    if not stat_data:
                        continue

                    # 跳过划价（带有stat-line类）
                    if stat_data.find(class_='stat-line'):
                        continue

                    # 检查红色价格
                    if stat_data.get('style', '') and '#C00000' in stat_data['style']:
                        price = stat_data.get_text(strip=True)
                        break

                    # 检查"Now"标签
                    stat_label = stat.find('div', class_='stat-label')
                    if stat_label and 'Now' in stat_label.get_text():
                        price = stat_data.get_text(strip=True)
                        break

                # 无红色/Now时取第一个非划价
                if not price:
                    for stat in stats:
                        stat_data = stat.find('div', class_='stat-data')
                        if stat_data and not stat_data.find(class_='stat-line'):
                            price = stat_data.get_text(strip=True)
                            break

                # 2. 提取STATUS：定位完成日期标签
                for stat in stats:
                    stat_label = stat.find('div', class_='stat-label')
                    if stat_label and 'Anticipated Completion Date' in stat_label.get_text():
                        stat_data = stat.find('div', class_='stat-data')
                        if stat_data:
                            status = stat_data.get_text(strip=True)
                            break

                # 清理价格数据（移除非数字字符）
                if price:
                    price = re.sub(r'[^\d.]', '', price)  # 保留数字和小数点

            # 提取房屋特征
            stats = {
                'bedrooms': '',
                'bathrooms': '',
                'garage': '',
                'sqft': ''
            }

            stats_container = soup.find('div', class_='QmiHero__statsBody')
            if stats_container:
                for stat in stats_container.find_all('div', class_='Qmi-stat'):
                    label = stat.find('div', class_='stat-label')
                    data = stat.find('div', class_='stat-data')
                    if label and data:
                        label_text = label.get_text(strip=True)
                        data_text = data.get_text(strip=True)
                        if 'Bedrooms' in label_text:
                            stats['bedrooms'] = data_text
                        elif 'Bathrooms' in label_text:
                            stats['bathrooms'] = data_text
                        elif 'Garage' in label_text:
                            # 提取数字部分
                            garage_value = re.findall(r'\d+', data_text)
                            stats['garage'] = garage_value[0] if garage_value else data_text.split('Car')[0].strip()
                        elif 'Sq Ft' in label_text:
                            stats['sqft'] = data_text

            # 组装数据
            home_data = {
                'date_scraped': datetime.now().strftime('%Y-%m-%d'),
                'builder': 'Pulte',
                'brand': 'pulte',
                'community': community,
                'address': address,
                'city': city,
                'state': state,
                'zip': zip_code,
                'plan_type': plan_type,
                'plan': plan_type,  # 与plan_type相同
                'floors': '',  # 网站未提供楼层信息
                'bedrooms': stats['bedrooms'],
                'full_bathrooms': stats['bathrooms'],  # 网站未区分全半卫
                'half_bathrooms': '',  # 网站未提供半卫信息
                'garage': stats['garage'],
                'sqft': stats['sqft'],
                'price': price if price else '',  # 使用新提取的价格
                'home_id': home_id,
                'status': status if status else '',  # 使用新提取的状态
                'link': url
            }

            return home_data

    except Exception as e:
        logging.error(f"爬取房源详情时出错: {url} - {str(e)}")
        logging.error(traceback.format_exc())
        return None


def save_to_csv(data, filename):
    if not data:
        return False

    file_exists = os.path.isfile(filename)
    headers = [
        'date_scraped', 'builder', 'brand', 'community', 'address', 'city', 'state', 'zip',
        'plan_type', 'plan', 'floors', 'bedrooms', 'full_bathrooms', 'half_bathrooms',
        'garage', 'sqft', 'price', 'home_id', 'status', 'link'
    ]

    try:
        with open(filename, 'a', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=headers)
            if not file_exists:
                writer.writeheader()
            writer.writerow(data)
        return True
    except Exception as e:
        logging.error(f"保存CSV时出错: {str(e)}")
        logging.error(traceback.format_exc())
        return False


def main():
    # 读取URL文件
    with open('urls.txt', 'r', encoding='utf-8') as f:
        region_paths = [line.strip() for line in f.readlines() if line.strip()]

    if not region_paths:
        logging.error("URL文件为空")
        return

    # 构建完整的区域URL
    base_url = "https://www.pulte.com"
    region_urls = [urljoin(base_url, path) for path in region_paths]

    # 创建CSV文件名
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    csv_filename = f"pulte_homes_{timestamp}.csv"

    logging.info(f"开始爬取，共 {len(region_urls)} 个区域")
    logging.info(f"结果将保存到: {csv_filename}")

    total_regions = len(region_urls)
    total_communities = 0
    total_homes = 0

    # 处理每个区域
    for region_idx, region_url in enumerate(region_urls, 1):
        try:
            logging.info(f"\n{'=' * 80}")
            logging.info(f"处理区域 [{region_idx}/{total_regions}]: {region_url}")

            # 提取社区
            communities = extract_communities_from_region(region_url)
            if not communities:
                logging.warning(f"该区域未找到任何社区: {region_url}")
                continue

            logging.info(f"找到 {len(communities)} 个社区")
            total_communities += len(communities)

            # 处理每个社区
            for comm_idx, community in enumerate(communities, 1):
                try:
                    logging.info(f"\n处理社区 [{comm_idx}/{len(communities)}]: {community['name']}")
                    logging.info(f"社区URL: {community['url']}")

                    # 提取房源链接
                    home_links, comm_name = extract_home_links(community['url'])
                    if not home_links:
                        logging.warning(f"该社区未找到任何房源: {community['name']}")
                        continue

                    logging.info(f"找到 {len(home_links)} 个房源")

                    # 处理每个房源
                    for home_idx, home_url in enumerate(home_links, 1):
                        try:
                            logging.info(f"处理房源 [{home_idx}/{len(home_links)}]: {home_url}")

                            # 爬取房源详情
                            home_data = scrape_home_detail(home_url)
                            if home_data:
                                # 保存到CSV
                                if save_to_csv(home_data, csv_filename):
                                    total_homes += 1
                                    logging.info(f"成功保存房源")
                                else:
                                    logging.warning(f"保存房源失败")
                            else:
                                logging.warning(f"爬取房源详情失败")

                            time.sleep(1.5)

                        except Exception as e:
                            logging.error(f"处理房源时发生错误: {home_url} - {str(e)}")
                            logging.error(traceback.format_exc())
                            continue

                except Exception as e:
                    logging.error(f"处理社区时发生错误: {community['name']} - {str(e)}")
                    logging.error(traceback.format_exc())
                    continue

                # 社区之间添加延迟
                time.sleep(2)

        except Exception as e:
            logging.error(f"处理区域时发生错误: {region_url} - {str(e)}")
            logging.error(traceback.format_exc())
            continue

        # 区域之间添加延迟
        time.sleep(3)

    # 最终报告
    logging.info(f"\n{'=' * 80}")
    logging.info(f"爬取完成!")
    logging.info(f"处理区域数: {total_regions}")
    logging.info(f"找到社区数: {total_communities}")
    logging.info(f"爬取房源数: {total_homes}")
    logging.info(f"所有数据已保存到: {csv_filename}")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        logging.info("\n用户中断程序")
    except Exception as e:
        logging.error(f"程序发生未处理异常: {str(e)}")
        logging.error(traceback.format_exc())
    finally:
        logging.info("程序结束")