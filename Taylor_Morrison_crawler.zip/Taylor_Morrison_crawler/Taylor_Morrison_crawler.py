import csv
import time
import random
import logging
from datetime import datetime
from playwright.sync_api import sync_playwright
from urllib.parse import urlparse

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger(__name__)

# 进度计数器
progress_counters = {
    'state': 0,
    'community': 0,
    'home': 0,
    'total_states': 0,
    'total_communities': 0,
    'total_homes': 0
}


def update_progress():
    """更新并显示进度信息"""
    state_info = f"州/市: {progress_counters['state']}/{progress_counters['total_states']}"
    comm_info = f"社区: {progress_counters['community']}/{progress_counters['total_communities']}"
    home_info = f"房源: {progress_counters['home']}/{progress_counters['total_homes']}"
    logger.info(f"进度 >> {state_info} | {comm_info} | {home_info}")


def extract_community_urls(state_url, context):
    """从州级页面提取社区URL"""
    logger.info(f"提取社区URL: {state_url}")
    page = context.new_page()
    try:
        page.goto(state_url, wait_until="domcontentloaded")

        # 等待社区卡片区域加载
        page.wait_for_selector('#search-page-community-card', timeout=15000)

        # 滚动加载所有内容
        for _ in range(5):
            page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
            time.sleep(1.5)

        # 提取社区URL
        community_urls = []
        cards = page.query_selector_all('section.tm-community-card')

        for card in cards:
            link = card.query_selector('a.search-page-available-home-card__home-detail-link') or \
                   card.query_selector('a.search-page-community-card__community-link')
            if link:
                href = link.get_attribute('href')
                if href:
                    full_url = f"https://www.taylormorrison.com{href}"
                    community_urls.append(full_url)

        logger.info(f"找到 {len(community_urls)} 个社区")
        return community_urls

    except Exception as e:
        logger.error(f"提取社区URL时出错: {str(e)}")
        return []
    finally:
        page.close()


def extract_home_urls(community_url, context):
    """从社区页面提取房源URL"""
    logger.info(f"提取房源URL: {community_url}")
    available_url = community_url.rstrip('/') + '/available-homes'

    page = context.new_page()
    try:
        page.goto(available_url, wait_until="domcontentloaded")

        # 检查是否有可用房屋
        if page.query_selector('div.community-available-homes-list__no-homes'):
            logger.info("该社区没有可用房屋")
            return []

        # 等待房屋列表加载
        page.wait_for_selector('.community-available-homes-list__listing-wrapper', timeout=10000)

        # 滚动加载所有内容
        for _ in range(3):
            page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
            time.sleep(1)

        # 提取房源URL
        home_urls = []
        cards = page.query_selector_all('.tm-home-card')

        for card in cards:
            link = card.query_selector('a[title="View Home"]')
            if link:
                href = link.get_attribute('href')
                if href:
                    full_url = f"https://www.taylormorrison.com{href}"
                    home_urls.append(full_url)

        logger.info(f"找到 {len(home_urls)} 个房源")
        return home_urls

    except Exception as e:
        logger.error(f"提取房源URL时出错: {str(e)}")
        return []
    finally:
        page.close()


def extract_info_from_url(url):
    """从URL中提取房源基本信息"""
    parsed = urlparse(url)
    path_parts = parsed.path.strip('/').split('/')

    state = path_parts[0] if path_parts else ""
    city = path_parts[1] if len(path_parts) > 1 else ""
    community = path_parts[3] if len(path_parts) > 3 else ""

    # 提取户型
    plan = ""
    if "floor-plans" in path_parts:
        idx = path_parts.index("floor-plans")
        if len(path_parts) > idx + 1:
            plan = path_parts[idx + 1]

    # 提取地址
    address = ""
    last_part = path_parts[-1] if path_parts else ""
    if "at-" in last_part:
        address_part = last_part.split("at-")[-1]
        address = address_part.replace('-', ' ').title()

    return {
        "state": state.upper(),
        "city": city.replace('-', ' ').title(),
        "community": community.replace('-', ' ').title(),
        "plan": plan.replace('-', ' ').title(),
        "status": "Available Now",
        "address": address
    }


def extract_features(page):
    """提取房源特征信息"""
    features = {}
    container = page.query_selector('div.tm-features, div.home-features, div.features-container')

    if container:
        items = container.query_selector_all('div.tm-features__item, div.feature-item')

        for item in items:
            try:
                value_elem = item.query_selector('div.tm-features__item-val, .feature-value')
                label_elem = item.query_selector('div.tm-features__item-label, .feature-label')

                if value_elem and label_elem:
                    value = value_elem.text_content().strip()
                    label = label_elem.text_content().strip().lower()

                    if "bed" in label:
                        features["bedrooms"] = value
                    elif "bath" in label:
                        if '.' in value:
                            full, half = value.split('.')
                            features["full_bathrooms"] = full
                            features["half_bathrooms"] = "1" if half.startswith('5') else "0"
                        else:
                            features["full_bathrooms"] = value
                            features["half_bathrooms"] = "0"
                    elif "sq" in label:
                        features["sqft"] = value.replace(',', '')
                    elif "garage" in label:
                        features["garage"] = value
                    elif "story" in label or "floor" in label:
                        features["floors"] = value
            except:
                continue
    return features


def extract_price(page):
    """提取价格信息"""
    try:
        price_elem = page.query_selector(
            'span.price-info__amount-value, div.price-info__amount, .home-price, [itemprop="price"]'
        )
        if price_elem:
            price = price_elem.text_content()
            return price.strip().replace('$', '').replace(',', '') if price else ""
    except:
        return ""


def extract_zip(page):
    """提取邮编信息"""
    try:
        address_elem = page.query_selector(
            'div.qmi-info--address, .home-address, [itemprop="address"]'
        )
        if address_elem:
            address_text = address_elem.text_content()
            if address_text:
                zip_match = re.search(r'\b(\d{5})\b', address_text)
                return zip_match.group(1) if zip_match else ""
    except:
        return ""


def scrape_home_page(url, context):
    """爬取单个房源详情"""
    logger.info(f"爬取房源: {url}")
    result = {
        "date_scraped": datetime.now().strftime("%Y-%m-%d"),
        "builder": "Taylor Morrison",
        "brand": "Taylor Morrison",
        "link": url,
        "home_id": "",
        "plan_type": "",
    }

    # 从URL提取基本信息
    url_info = extract_info_from_url(url)
    result.update(url_info)

    page = context.new_page()
    try:
        page.goto(url, wait_until="domcontentloaded")

        # 提取特征
        features = extract_features(page)
        result.update(features)

        # 提取价格
        result["price"] = extract_price(page)

        # 提取邮编
        result["zip"] = extract_zip(page)

        return result
    except Exception as e:
        logger.error(f"爬取房源失败: {str(e)}")
        return None
    finally:
        page.close()


def save_home_data(data, csv_writer, file_handle):
    """保存房源数据到CSV"""
    if not data:
        return

    # 字段顺序
    fieldnames = [
        "date_scraped", "builder", "brand", "community", "address", "city", "state", "zip",
        "plan_type", "plan", "floors", "bedrooms", "full_bathrooms", "half_bathrooms",
        "garage", "sqft", "price", "home_id", "status", "link"
    ]

    # 创建完整数据行
    row = {field: data.get(field, "") for field in fieldnames}

    # 写入CSV
    csv_writer.writerow(row)
    file_handle.flush()  # 立即写入磁盘
    logger.info("数据已保存")


def main():
    # 读取URL列表
    try:
        with open("urls.txt", "r") as f:
            state_urls = [line.strip() for line in f if line.strip()]
    except Exception as e:
        logger.error(f"读取URL文件失败: {str(e)}")
        return

    # 初始化进度计数器
    progress_counters['total_states'] = len(state_urls)

    # 创建CSV文件
    csv_file = "taylor_morrison_homes.csv"
    fieldnames = [
        "date_scraped", "builder", "brand", "community", "address", "city", "state", "zip",
        "plan_type", "plan", "floors", "bedrooms", "full_bathrooms", "half_bathrooms",
        "garage", "sqft", "price", "home_id", "status", "link"
    ]

    # 打开CSV文件（追加模式）
    with open(csv_file, 'a', newline='', encoding='utf-8') as csv_handle:
        writer = csv.DictWriter(csv_handle, fieldnames=fieldnames)

        # 如果是新文件，写入表头
        if csv_handle.tell() == 0:
            writer.writeheader()

        # 启动Playwright
        with sync_playwright() as p:
            # 启动浏览器
            browser = p.chromium.launch(
                headless=True,
                args=[
                    "--disable-blink-features=AutomationControlled",
                    "--no-sandbox",
                    "--disable-gpu",
                    "--disable-web-security"
                ]
            )

            # 创建浏览器上下文
            context = browser.new_context(
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36",
                viewport={"width": 1366, "height": 768}
            )

            # 隐藏自动化特征
            context.add_init_script("""
                Object.defineProperty(navigator, 'webdriver', {
                    get: () => undefined
                });
            """)

            # 处理每个州/市URL
            for state_url in state_urls:
                progress_counters['state'] += 1
                progress_counters['community'] = 0
                update_progress()

                try:
                    # 提取社区URL
                    community_urls = extract_community_urls(state_url, context)
                    progress_counters['total_communities'] += len(community_urls)

                    # 处理每个社区
                    for community_url in community_urls:
                        progress_counters['community'] += 1
                        progress_counters['home'] = 0
                        update_progress()

                        try:
                            # 提取房源URL
                            home_urls = extract_home_urls(community_url, context)
                            progress_counters['total_homes'] += len(home_urls)

                            # 处理每个房源
                            for home_url in home_urls:
                                progress_counters['home'] += 1
                                update_progress()

                                try:
                                    # 爬取房源详情
                                    home_data = scrape_home_page(home_url, context)

                                    # 保存数据
                                    if home_data:
                                        save_home_data(home_data, writer, csv_handle)
                                except Exception as e:
                                    logger.error(f"处理房源失败: {str(e)}")

                                # 随机延迟
                                time.sleep(random.uniform(1, 2))

                            # 社区间延迟
                            time.sleep(random.uniform(2, 3))
                        except Exception as e:
                            logger.error(f"处理社区失败: {str(e)}")

                    # 州/市间延迟
                    time.sleep(random.uniform(3, 5))
                except Exception as e:
                    logger.error(f"处理州/市失败: {str(e)}")

            # 关闭浏览器
            browser.close()

    logger.info("任务完成")


if __name__ == "__main__":
    import re

    main()