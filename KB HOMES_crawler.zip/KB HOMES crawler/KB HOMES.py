import requests
from bs4 import BeautifulSoup
import re
import csv
from datetime import datetime
import time
import urllib3
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from urllib.parse import urlparse, parse_qs
from playwright.sync_api import sync_playwright
import os
import traceback

# 禁用SSL警告
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# 全局变量用于状态跟踪
current_county = ""
current_community = ""
current_house = ""
errors = []
error_urls = []  # 存储出错的URL
written_urls = set()  # 存储已写入的URL，用于检测重复
total_homes_scraped = 0  # 跟踪总共爬取的房源数量


def create_session():
    """创建带有重试机制的requests会话"""
    session = requests.Session()
    retry_strategy = Retry(
        total=2,
        backoff_factor=1,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["GET"]
    )
    adapter = HTTPAdapter(max_retries=retry_strategy)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    return session


def scrape_county_page(county_url):
    """使用Playwright从县的页面提取所有社区URL"""
    global current_county, errors

    current_county = county_url
    print(f"\n{'=' * 50}")
    print(f"开始处理县: {county_url}")
    print(f"{'=' * 50}")

    community_urls = []

    with sync_playwright() as p:
        # 启动浏览器
        browser = p.chromium.launch(headless=True)
        context = browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.54 Safari/537.36",
            viewport={"width": 1280, "height": 720}
        )
        page = context.new_page()

        try:
            # 访问县的页面
            page.goto(county_url, timeout=150000)
            print(f"✅ 成功访问页面: {county_url}")

            # 等待页面加载完成
            page.wait_for_load_state("networkidle", timeout=100000)
            print("✅ 页面加载完成")

            # 尝试滚动页面以加载所有内容
            page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
            time.sleep(2)  # 减少等待时间

            # 查找社区列表容器
            community_container = page.locator("div.communities-filtered")
            if community_container.count() == 0:
                community_container = page.locator("div.container.scroll-list.community-list.custom-scrollbar")

            if community_container.count() > 0:
                # 提取所有社区项目
                community_items = community_container.locator("div.row.community-item")
                total_items = community_items.count()
                print(f"📊 找到 {total_items} 个社区项目")

                # 提取每个社区项目的URL
                for i in range(total_items):
                    item = community_items.nth(i)

                    # 查找"Explore"按钮
                    explore_btn = item.locator("a.btn-primary.btn-explore")

                    if explore_btn.count() > 0:
                        href = explore_btn.get_attribute("href")
                        if href:
                            if not href.startswith("http"):
                                href = f"https://www.kbhome.com{href}"
                            community_urls.append(href)
                    else:
                        # 尝试其他方法获取URL
                        link = item.locator("a").first
                        if link.count() > 0:
                            href = link.get_attribute("href")
                            if href:
                                if not href.startswith("http"):
                                    href = f"https://www.kbhome.com{href}"
                                community_urls.append(href)
            else:
                # 在全页面查找所有Explore按钮
                explore_buttons = page.locator("a.btn-primary.btn-explore")
                total_buttons = explore_buttons.count()
                print(f"🔍 在全页面找到 {total_buttons} 个Explore按钮")

                for i in range(total_buttons):
                    btn = explore_buttons.nth(i)
                    href = btn.get_attribute("href")
                    if href:
                        if not href.startswith("http"):
                            href = f"https://www.kbhome.com{href}"
                        community_urls.append(href)

            # 如果仍未找到，尝试备用方法
            if not community_urls:
                # 尝试查找所有社区链接
                community_links = page.locator("a[href^='/new-homes-']")
                total_links = community_links.count()

                for i in range(total_links):
                    link = community_links.nth(i)
                    href = link.get_attribute("href")
                    if href and "/new-homes-" in href and "/" in href[len("/new-homes-"):]:
                        if not href.startswith("http"):
                            href = f"https://www.kbhome.com{href}"
                        community_urls.append(href)

            print(f"✅ 共找到 {len(community_urls)} 个社区URL")
            return community_urls

        except Exception as e:
            error_msg = f"提取县社区URL出错: {county_url} | {str(e)}"
            print(f"⚠️ {error_msg}")
            errors.append(error_msg)
            return []
        finally:
            # 关闭浏览器
            browser.close()


def is_valid_community_url(url):
    # 过滤掉空URL、锚点URL和过短的URL
    if not url or url == "#" or len(url) < 10:
        return False

    # 检查URL路径是否符合社区URL的模式
    path = url.replace("https://www.kbhome.com", "").lower()
    if not path.startswith("/new-homes"):
        return False

    return True


def scrape_community_page(community_url):
    """使用 Playwright 爬取社区页面，提取所有去重后的房源URL"""
    global current_community, errors

    current_community = community_url
    print(f"\n开始处理社区: {community_url}")

    # 使用集合存储URL，自动去重
    unique_urls = set()

    with sync_playwright() as p:
        # 启动浏览器
        browser = p.chromium.launch(headless=True)
        context = browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.54 Safari/537.36"
        )
        page = context.new_page()

        try:
            # 访问社区页面
            page.goto(community_url, timeout=150000)
            print(f"✅ 成功访问页面")

            # 等待页面加载完成
            page.wait_for_load_state("networkidle", timeout=100000)

            # 尝试点击"Move-in Ready Homes"标签
            try:
                move_in_tab = page.locator("a#moveinready-tab")
                if move_in_tab.is_visible():
                    move_in_tab.click()
                    # 等待内容加载
                    page.wait_for_load_state("networkidle", timeout=30000)
            except:
                pass

            # 提取Personalized Homes类型的房源
            personalized_div = page.locator("div#floorPlans")
            if personalized_div.count() > 0:
                personalized_cards = personalized_div.locator("div.card-item")
                for i in range(personalized_cards.count()):
                    card = personalized_cards.nth(i)
                    a_tag = card.locator("a").first
                    if a_tag.count() > 0:
                        href = a_tag.get_attribute("href")
                        if href and href != "#" and len(href) > 10:  # 过滤无效URL
                            if not href.startswith("http"):
                                href = f"https://www.kbhome.com{href}"
                            unique_urls.add(href)

            # 提取Move-in Ready Homes类型的房源
            mir_div = page.locator("div#mir")
            if mir_div.count() > 0:
                mir_cards = mir_div.locator("div.card-item")
                for i in range(mir_cards.count()):
                    card = mir_cards.nth(i)
                    a_tag = card.locator("a").first
                    if a_tag.count() > 0:
                        href = a_tag.get_attribute("href")
                        if href and href != "#" and len(href) > 10:  # 过滤无效URL
                            if not href.startswith("http"):
                                href = f"https://www.kbhome.com{href}"
                            unique_urls.add(href)

            # 检查是否有"See all"链接
            see_all_link = page.locator("div#mir-cards-footer a")
            if see_all_link.count() > 0:
                see_all_href = see_all_link.get_attribute("href")
                if see_all_href:
                    # 访问"See all"页面
                    if not see_all_href.startswith("http"):
                        see_all_href = f"https://www.kbhome.com{see_all_href}"

                    # 创建新页面处理"See all"链接
                    see_all_page = context.new_page()
                    see_all_page.goto(see_all_href, timeout=60000)
                    see_all_page.wait_for_load_state("networkidle", timeout=30000)

                    # 处理分页
                    pagination = see_all_page.locator("ul.mir-pagination")
                    if pagination.count() > 0:
                        # 获取总页数
                        page_items = pagination.locator("li.pagintation-item")
                        total_pages = page_items.count()

                        # 处理每一页
                        for page_num in range(1, total_pages + 1):
                            if page_num > 1:
                                # 点击页码
                                page_btn = see_all_page.locator(
                                    f"ul.mir-pagination li.pagintation-item:nth-child({page_num}) a")
                                if page_btn.count() > 0:
                                    page_btn.click()
                                    see_all_page.wait_for_load_state("networkidle", timeout=30000)

                            # 提取当前页的房源URL
                            cards = see_all_page.locator("div.mir-home-card-container")
                            for i in range(cards.count()):
                                card = cards.nth(i)
                                # 获取卡片内的第一个<a>标签（主要房源链接）
                                a_tag = card.locator("a").first
                                if a_tag.count() > 0:
                                    href = a_tag.get_attribute("href")
                                    if href and href != "#" and len(href) > 10:
                                        if not href.startswith("http"):
                                            href = f"https://www.kbhome.com{href}"
                                        unique_urls.add(href)

                    # 关闭"See all"页面
                    see_all_page.close()

            print(f"✅ 共找到 {len(unique_urls)} 个去重房源链接")
            return list(unique_urls)

        except Exception as e:
            error_msg = f"提取社区房源出错: {community_url} | {str(e)}"
            print(f"⚠️ {error_msg}")
            errors.append(error_msg)
            return []
        finally:
            # 关闭浏览器
            browser.close()


def extract_property_details(soup):
    """提取房屋属性"""
    details = {
        'bedrooms': "",
        'full_bathrooms': "",
        'half_bathrooms': "",
        'garage': "",
        'floors': "",
        'sqft': ""
    }

    # 查找属性容器
    containers = [
        soup.find('div', class_='specs-container'),
        soup.find('div', class_='home-specs'),
        soup.find('div', class_='specs'),
        soup.find('div', class_='details-holder')
    ]

    property_container = None
    for container in containers:
        if container:
            property_container = container
            break

    # 如果找不到特定容器，尝试查找包含所有属性的行
    if not property_container:
        rows = soup.find_all('div', class_='row')
        if rows:
            for row in rows:
                cols = row.find_all('div', class_='col')
                if cols and len(cols) >= 4:
                    property_container = row
                    break

    if property_container:
        cols = property_container.find_all('div', class_='col')
        if not cols:
            cols = property_container.find_all('div', class_='spec-item')
        if not cols:
            cols = property_container.find_all('div', recursive=False)

        if cols:
            # 处理每列数据
            for col in cols:
                text = col.get_text(strip=True).upper()
                if not text:
                    continue

                # 查找数值元素
                value_element = col.find('span') or col
                value_text = value_element.get_text(strip=True) if value_element else ""

                # 提取数字值
                number_match = re.search(r'[\d\.,]+', value_text)
                if not number_match:
                    continue

                value = number_match.group(0).replace(',', '')

                # 匹配属性类型
                if 'BED' in text or 'BEDS' in text:
                    details['bedrooms'] = value
                elif 'BATH' in text or 'BATHS' in text:
                    if '.' in value:
                        full, half = value.split('.')
                        details['full_bathrooms'] = full
                        details['half_bathrooms'] = "1"
                    else:
                        details['full_bathrooms'] = value
                        details['half_bathrooms'] = "0"
                elif 'CAR' in text or 'GARAGE' in text:
                    details['garage'] = value
                elif 'FLOOR' in text or 'STORY' in text or 'STORIES' in text:
                    details['floors'] = value
                elif 'SQ' in text or 'FT' in text or 'SQFT' in text:
                    details['sqft'] = value

    # 如果仍未找到所有属性，尝试直接搜索整个页面
    if not all(details.values()):
        # 尝试在整个页面中搜索各个属性
        all_divs = soup.find_all(['div', 'span'])
        for element in all_divs:
            text = element.get_text(strip=True).upper()
            if not text:
                continue

            # 提取数字部分
            number_match = re.search(r'[\d\.]+', text)
            if not number_match:
                continue

            value = number_match.group(0)

            # 检查各个属性类型
            if 'BED' in text or 'BEDS' in text:
                details['bedrooms'] = value
            elif 'BATH' in text or 'BATHS' in text:
                if '.' in value:
                    parts = value.split('.')
                    details['full_bathrooms'] = parts[0]
                    details['half_bathrooms'] = "1"
                else:
                    details['full_bathrooms'] = value
                    details['half_bathrooms'] = "0"
            elif 'CAR' in text or 'GARAGE' in text:
                details['garage'] = value
            elif 'FLOOR' in text or 'STORY' in text or 'STORIES' in text:
                details['floors'] = value
            elif 'SQ' in text or 'FT' in text or 'SQFT' in text:
                details['sqft'] = value.replace(',', '')

    return details


def scrape_home_page(url):
    """爬取单个房源信息"""
    global current_house, errors, error_urls, total_homes_scraped

    current_house = url

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.54 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        'Connection': 'keep-alive'
    }

    session = create_session()

    try:
        # 使用verify=False跳过SSL验证
        response = session.get(url, headers=headers, verify=False, timeout=30)

        # 检查响应状态
        if response.status_code != 200:
            error_msg = f"错误状态码 {response.status_code}: {url}"
            errors.append(error_msg)
            error_urls.append(url)  # 添加到错误URL列表
            return None

        # 解析HTML
        soup = BeautifulSoup(response.text, 'html.parser')

        # 从URL中提取社区
        path_segments = urlparse(url).path.strip('/').split('/')
        community = path_segments[-2] if len(path_segments) > 1 else ""

        # 从URL中提取home_id
        parsed_url = urlparse(url)
        query_params = parse_qs(parsed_url.query)

        # 1. 优先从查询参数获取homesite
        home_id = query_params.get('homesite', [''])[0]

        # 2. 若查询参数中无homesite，则从路径最后一段提取
        if not home_id:
            home_id = path_segments[-1] if path_segments else ""

        # 提取状态
        status_tag = soup.find('span', class_='tag-label') or soup.find('div', class_='tag-label')
        status = status_tag.get_text(strip=True) if status_tag else ""

        # 提取地址信息
        location_div = soup.find('div', class_='location-item') or soup.find('div', class_='address-container')
        location_text = ""
        if location_div:
            a_tag = location_div.find('a', class_='text-link')
            if not a_tag:
                a_tag = location_div.find('a', class_='cta-directions')

            if a_tag:
                location_text = a_tag.get_text(strip=True)
            else:
                location_text = location_div.get_text(strip=True)

        # 解析城市、州和邮编
        city = state = zip_code = ""
        if location_text:
            # 尝试两种不同的匹配模式
            match = re.search(r',\s*([^,]+?)\s*,\s*([A-Z]{2})\s*(\d{5})$', location_text)
            if not match:
                match = re.search(r',\s*([^,]+?)\s*,\s*([A-Z]{2})\s*$', location_text)

            if match:
                city = match.group(1).strip()
                if len(match.groups()) >= 2:
                    state = match.group(2).strip()
                if len(match.groups()) >= 3:
                    zip_code = match.group(3).strip()

        # 提取价格
        price = ""
        price_div = soup.find('div', class_='detail-item') or soup.find('div', class_='price-container')
        if price_div:
            price_span = price_div.find('span', class_='price') or price_div.find('span', class_='pl-1')
            if not price_span:
                # 尝试其他价格选择器
                price_span = price_div.find('span', class_=lambda x: x != 'vertical-divider' and x)

            if price_span:
                price_text = price_span.get_text(strip=True)
                # 提取数字部分
                numbers = re.findall(r'[\d,]+', price_text)
                if numbers:
                    price = numbers[0].replace(',', '')
            else:
                # 尝试直接搜索价格文本
                price_match = re.search(r'\$\s*([\d,]+)', price_div.get_text())
                if price_match:
                    price = price_match.group(1).replace(',', '')

        # 提取房屋属性
        property_details = extract_property_details(soup)

        # 提取plan和plan_type
        plan = plan_type = ""
        title_tag = soup.find('h1', class_='plan-title') or soup.find('h1', class_='home-title')
        if title_tag:
            title_text = title_tag.get_text(strip=True)
            plan = re.sub(r'\s+', ' ', title_text)

            if '|' in title_text:
                parts = title_text.split('|')
                plan = parts[-1].strip()
                if 'Plan' in title_text or 'plan' in title_text:
                    plan_type = "Home Plan"

        # 准备数据
        if '|' in location_text:
            address = location_text.split('|')[-1].split(',')[0].strip()
        else:
            address = location_text.split(',')[0].strip() if location_text else ""

        data = {
            'date_scraped': datetime.now().strftime('%Y-%m-%d'),
            'builder': 'KB Homes',
            'brand': 'KB Homes',
            'community': community,
            'address': address,
            'city': city,
            'state': state,
            'zip': zip_code,
            'plan_type': plan_type,
            'plan': plan,
            'floors': property_details['floors'],
            'bedrooms': property_details['bedrooms'],
            'full_bathrooms': property_details['full_bathrooms'],
            'half_bathrooms': property_details['half_bathrooms'],
            'garage': property_details['garage'],
            'sqft': property_details['sqft'],
            'price': price,
            'home_id': home_id,
            'status': status,
            'link': url
        }

        total_homes_scraped += 1
        return data

    except Exception as e:
        error_msg = f"爬取房源出错: {url} | {str(e)}"
        errors.append(error_msg)
        error_urls.append(url)  # 添加到错误URL列表
        return None
    finally:
        session.close()


def save_to_csv(data, filename='kb_homes.csv'):
    """将数据保存到CSV文件，检查重复项"""
    global written_urls

    if not data:
        return False

    # 检查URL是否已经写入过
    if data['link'] in written_urls:
        return False

    fieldnames = [
        'date_scraped', 'builder', 'brand', 'community', 'address', 'city',
        'state', 'zip', 'plan_type', 'plan', 'floors', 'bedrooms',
        'full_bathrooms', 'half_bathrooms', 'garage', 'sqft', 'price',
        'home_id', 'status', 'link'
    ]

    try:
        with open(filename, 'a', newline='', encoding='utf-8') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            if csvfile.tell() == 0:
                writer.writeheader()
            writer.writerow(data)
        written_urls.add(data['link'])  # 添加到已写入集合
        return True
    except Exception as e:
        error_msg = f"保存到CSV失败: {e}"
        errors.append(error_msg)
        return False


def is_valid_url(url):
    """检查URL是否是有效的房源URL"""
    # 过滤掉空URL、锚点URL和过短的URL
    if not url or url == "#" or len(url) < 10:
        return False

    # 检查URL路径是否符合房源URL的模式
    path = url.replace("https://www.kbhome.com", "").lower()
    if not ("/plan-" in path or "/mir?" in path):
        return False

    return True


def read_county_urls(filename='links.txt'):
    """从文本文件读取县URL"""
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            urls = [line.strip() for line in f.readlines() if line.strip()]
        print(f"✅ 从 {filename} 读取了 {len(urls)} 个县URL")
        return urls
    except Exception as e:
        print(f"⚠️ 读取县URL文件失败: {e}")
        return []


def save_error_urls():
    """保存出错的URL到文件"""
    global error_urls
    if error_urls:
        filename = 'error_urls.txt'
        with open(filename, 'w', encoding='utf-8') as f:
            for url in error_urls:
                f.write(url + '\n')
        print(f"⚠️ 保存了 {len(error_urls)} 个错误URL到 {filename}")


def main():
    global errors, error_urls, written_urls, total_homes_scraped

    # 从文件读取县URL
    county_urls = read_county_urls('links.txt')
    if not county_urls:
        print("没有可用的县URL，程序退出")
        return

    # 清空或创建CSV文件
    csv_filename = 'kb_homes_0704.csv'
    if os.path.exists(csv_filename):
        os.remove(csv_filename)
        print(f"已删除存在的CSV文件: {csv_filename}")

    # 初始化已写入URL集合
    written_urls = set()

    print(f"开始爬取 {len(county_urls)} 个县的数据...")
    start_time = time.time()
    last_print_time = time.time()
    print_interval = 60  # 每分钟打印一次进度

    # 处理每个县
    for county_idx, county_url in enumerate(county_urls, 1):
        current_county = county_url
        print(f"\n处理县 {county_idx}/{len(county_urls)}: {county_url}")

        # 获取县的所有社区URL
        community_urls = scrape_county_page(county_url)

        # 过滤无效URL
        valid_community_urls = [url for url in community_urls if is_valid_community_url(url)]

        if not valid_community_urls:
            error_msg = f"县 {county_url} 未找到有效社区，跳过"
            print(f"⚠️ {error_msg}")
            errors.append(error_msg)
            continue

        print(f"✅ 找到 {len(valid_community_urls)} 个有效社区")

        # 处理每个社区
        for comm_idx, community_url in enumerate(valid_community_urls, 1):
            current_community = community_url
            print(f"  处理社区 {comm_idx}/{len(valid_community_urls)}: {community_url}")

            # 获取社区的所有房源URL
            home_urls = scrape_community_page(community_url)

            # 过滤无效URL
            valid_home_urls = [url for url in home_urls if is_valid_url(url)]

            if not valid_home_urls:
                error_msg = f"社区 {community_url} 未找到有效房源，跳过"
                print(f"⚠️ {error_msg}")
                errors.append(error_msg)
                continue

            print(f"    找到 {len(valid_home_urls)} 个有效房源")

            # 处理每个房源 - 不再重试，出错直接跳过
            success_count = 0
            for home_idx, home_url in enumerate(valid_home_urls, 1):
                current_house = home_url

                # 随机延迟以避免请求过频繁
                if home_idx % 10 == 0:
                    time.sleep(0.3)

                # 仅尝试一次，出错直接跳过
                home_data = scrape_home_page(home_url)
                if home_data:
                    if save_to_csv(home_data, csv_filename):
                        success_count += 1

                # 定期打印进度
                current_time = time.time()
                if current_time - last_print_time > print_interval:
                    print(f"    进度: {home_idx}/{len(valid_home_urls)} 房源 | 成功: {success_count}")
                    last_print_time = current_time

            print(f"    社区完成: {success_count}/{len(valid_home_urls)} 房源爬取成功")

        # 更新县进度
        county_percent = county_idx / len(county_urls) * 100
        elapsed = time.time() - start_time
        avg_time_per_county = elapsed / county_idx
        remaining_counties = len(county_urls) - county_idx
        estimated_remaining = avg_time_per_county * remaining_counties

        if estimated_remaining > 60:
            print(f"⏱ 预计剩余时间: {estimated_remaining / 60:.1f} 分钟")
        else:
            print(f"⏱ 预计剩余时间: {estimated_remaining:.1f} 秒")

    # 爬取完成
    elapsed_total = time.time() - start_time
    print("\n" + "=" * 50)
    print(f"✅ 所有县爬取完成! 总耗时: {elapsed_total / 60:.2f} 分钟")
    print(f"✅ 数据已保存到: {csv_filename}")
    print(f"✅ 成功爬取房源数量: {total_homes_scraped}")
    print(f"⚠️ 错误数量: {len(errors)}")
    print("=" * 50)

    # 保存错误URL到文件
    save_error_urls()

    # 保存错误日志
    if errors:
        with open('crawler_errors.log', 'w', encoding='utf-8') as f:
            f.write("\n".join(errors))
        print(f"⚠️ 错误日志已保存到: crawler_errors.log")


if __name__ == "__main__":
    main()